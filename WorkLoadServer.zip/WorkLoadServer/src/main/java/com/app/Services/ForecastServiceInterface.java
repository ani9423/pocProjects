package com.app.Services;

public interface ForecastServiceInterface {

	public void getForecastValues();
}

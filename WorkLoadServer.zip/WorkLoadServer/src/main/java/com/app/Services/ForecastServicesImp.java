package com.app.Services;

import java.io.FileInputStream;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.google.api.gax.core.CredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.MessageReceiver;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;


@Component
@EnableAsync
public class ForecastServicesImp implements ForecastServiceInterface {
      
	  @Value("${gcp.project}")
	  private String projectId="graphical-elf-409902";
	  
	  @Value("$(gcp.subscriptionId)")
	  private String subscriptionId="forecastdataSub";
	  
	  
	  @Value("${serviceaccount.key}")
	  String credentialsFilePath="D:/Downloads/graphical-elf-409902-8d3c72c66aa3.json";
	  
	  ProjectSubscriptionName subscriptionName;
	  
	  CredentialsProvider credentialsProvider;

	
	
	public ForecastServicesImp() {
		
		System.out.println("inside ForecastServicesImp");
		subscriptionName = ProjectSubscriptionName.of(projectId, subscriptionId);
		credentialsProvider = () -> GoogleCredentials.fromStream(new FileInputStream(credentialsFilePath));
	}



	
	@Async
	@Scheduled(fixedRate=5000)
	public void getForecastValues() {
	//System.out.println("LocalDate "+LocalDateTime.now());	
	Subscriber subscriber= Subscriber.newBuilder(subscriptionName,messageReceiver()).setCredentialsProvider(credentialsProvider).build();
	subscriber.startAsync().awaitRunning();	
	}
	
	public  MessageReceiver  messageReceiver()
	{
		return new MessageReceiver() {

			@Override
			public void receiveMessage(PubsubMessage message, AckReplyConsumer consumer) {
				String a=null;
				if((a=message.getData().toStringUtf8())!=null)
				{
			    System.out.println("pubSubMessage Recived>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+a);
			    consumer.ack();
				}
				
			}
			
		};
	}

}

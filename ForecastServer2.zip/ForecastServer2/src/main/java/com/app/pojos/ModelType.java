package com.app.pojos;

public enum ModelType {
  CROSTON,AVG,MOVAVG
}

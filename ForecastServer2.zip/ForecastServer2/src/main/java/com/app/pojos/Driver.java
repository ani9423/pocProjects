package com.app.pojos;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString

public class Driver extends BaseEntity {
 
	
	private String driverId;
	
	
	@OneToMany
	private List<Store> store = new ArrayList<Store>();
	
	@ManyToOne
	private Model model;
	
	

	public Driver(String driverId, List<Store> store, Model model) {
		super();
		this.driverId = driverId;
		
		this.store = store;
		this.model = model;
	}



	public Driver() {
		
	}
	
	
}

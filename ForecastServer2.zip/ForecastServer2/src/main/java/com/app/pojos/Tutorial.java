package com.app.pojos;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class Tutorial extends BaseEntity {

	private String name;
	
	private String content;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private Topic selectedTopic;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	private User auther;
    
	private Long vistis;

	public Tutorial(String name, String content, Long visits) {
		super();
		this.name = name;
		this.content = content;
		this.vistis= visits;
		
	}

	public Tutorial() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Topic getSelectedTopic() {
		return selectedTopic;
	}

	public void setSelectedTopic(Topic selectedTopic) {
		this.selectedTopic = selectedTopic;
	}

	public User getAuther() {
		return auther;
	}

	public void setAuther(User auther) {
		this.auther = auther;
	}

	public Long getVistis() {
		return vistis;
	}

	public void setVistis(Long vistis) {
		this.vistis = vistis;
	}

	@Override
	public String toString() {
		return "Tutorial [name=" + name + ", content=" + content + ", selectedTopic=" + selectedTopic + ", auther="
				+ auther + ", vistis=" + vistis + "]";
	}
	
	
	
	
	
	
}

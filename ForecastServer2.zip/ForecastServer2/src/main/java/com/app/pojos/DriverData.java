package com.app.pojos;

import java.sql.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
public class DriverData extends BaseEntity {
	
	private double actualData;
	
	private double forecastedData;
	
	
	private Date date;
	
	@ManyToOne
	private Driver driver;

	public DriverData() {
		
	}

	public DriverData(double actualData, double forecastedData, Date date, Driver driver) {
		super();
		this.actualData = actualData;
		this.forecastedData = forecastedData;
		this.date = date;
		this.driver = driver;
	}
	
	
    
}

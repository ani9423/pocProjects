package com.app.pojos;

import javax.persistence.Entity;

@Entity
public class Topic extends BaseEntity {
  
	private String name;
	
	private String description;

	public Topic(String name, String description) {
		super();
		this.name = name;
		this.description = description;
	}

	public Topic() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Topic [name=" + name + ", description=" + description + "]";
	}
	
	
	
	
	
}

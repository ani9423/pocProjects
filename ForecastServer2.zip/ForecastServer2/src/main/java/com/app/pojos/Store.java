package com.app.pojos;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString

public class Store extends BaseEntity {
	
 @Column(unique=true)
 private String storeId;
 
 private String Location;
 
 private Date effectiveDate;

public Store(String storeId, String location, Date effectiveDate) {
	super();
	this.storeId = storeId;
	Location = location;
	this.effectiveDate = effectiveDate;
}

public Store() {
	
}
 
 
}

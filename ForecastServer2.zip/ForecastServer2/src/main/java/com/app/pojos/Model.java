package com.app.pojos;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString

public class  Model extends BaseEntity  {
     
	private String modelId;
	
	@Enumerated(EnumType.STRING)
	private ModelType modelName;

	public Model(String modelId, ModelType modelName) {
		super();
		this.modelId = modelId;
		this.modelName = modelName;
	}

	public Model() {
		
	}
	
	


	
	
}

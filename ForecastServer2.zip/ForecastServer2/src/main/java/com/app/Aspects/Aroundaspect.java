package com.app.Aspects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class Aroundaspect {
	
	@Around(value="execution(* com.app.controller.*.*(..))")
	public Object methodaroud1(ProceedingJoinPoint joinpooint) throws Throwable {
		log.info("in around before {} {}",joinpooint.getSignature(),System.currentTimeMillis());
		Object result=joinpooint.proceed();
		log.info("in around after {} {}",joinpooint.getSignature(),System.currentTimeMillis());
		return result;
	}
	

}

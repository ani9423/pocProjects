package com.app.Aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class AfterAopAspect {
	    
       @After(value="execution(* com.app.controller.*.*(..))")
       public void method1(JoinPoint joinPoint)
       {
    	   log.info("in after {}", joinPoint.getSignature());
       }
       
       @AfterReturning(value="execution(* com.app.controller.*.*(..))",returning="result123")
       public void method2(JoinPoint joinPoint, Object result123 )
       {
    	   log.info("in after retrning with value {} ",result123 );
       }
}

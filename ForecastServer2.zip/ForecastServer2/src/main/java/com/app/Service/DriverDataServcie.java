package com.app.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.Dao.DataRepo;
import com.app.Dao.DriverDao;
//import com.app.ForecastModels.Croston;
import com.app.ForecastModels.Forecast;
import com.app.pojos.Driver;
import com.app.pojos.DriverData;
import com.app.pojos.Model;
import com.app.pojos.ModelType;

@Service
@Transactional
public class DriverDataServcie implements DriverDataServiceInterface {

	@Autowired
	private DataRepo dataRepo;
	
	@Autowired
	private DriverDao driverDao;
	
	@Autowired
	private Forecast forecast;
	
	
	@Override
	public List<DriverData> getDriverData(Long DriverID) {
		
		return dataRepo.getDataByDriverId(DriverID);
	}

	@Override
	public DriverData saveData(DriverData driverData) {
		
		return dataRepo.save(driverData);
	}

	@Override
	public double forecastData(String driverId, LocalDate date) {
		
		Driver driver=  driverDao.findByDriverId(driverId);//fetch driver Object from DB
		
		
		Model model=driver.getModel();//fetch model Object from DB
		
		
		ModelType type = model.getModelName();
		
		List<DriverData> data=new ArrayList<>();
		
		LocalDate oneDayBehindDate=date;
		
		int dId = driverDao.getDriverId(driverId);
		
		for(int i =0 ; i<3; i++)
		{
	    oneDayBehindDate = oneDayBehindDate.minusDays(1);	
	    DriverData fetchedData= dataRepo.getDataByDateAndDriver(Long.valueOf(dId), Date.valueOf(oneDayBehindDate))	;
		data.add(fetchedData);	
		}
		
		Double Forecastresult= (double) 0;
		
		
		Forecastresult = forecast.forecastData(data,type);
		
		
		
		
		
		return Forecastresult;
	}

}

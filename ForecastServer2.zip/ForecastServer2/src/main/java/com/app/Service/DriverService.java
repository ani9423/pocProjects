package com.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.Dao.DriverDao;
import com.app.pojos.Driver;

@Service
@Transactional
public class DriverService implements DriverServcieinterface {

	@Autowired
	private DriverDao driverDao;
	
	@Override
	public Driver addDriver(Driver driver) {
		
		return driverDao.save(driver);
	}

	@Override
	public List<Driver> getAll() {
		
		return driverDao.findAll();
	}

}

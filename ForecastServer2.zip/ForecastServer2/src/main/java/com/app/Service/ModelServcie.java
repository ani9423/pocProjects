package com.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.Dao.ModelRepo;
import com.app.pojos.Model;
@Service
@Transactional
public class ModelServcie implements ModelServiceInterface {

	
	@Autowired
	private ModelRepo modelDao;
	
	@Override
	public Model addModel(Model model) {
		
		return modelDao.save(model);
	}

	@Override
	public List<Model> getAllModel() {
		// TODO Auto-generated method stub
		return modelDao.findAll();
	}

}

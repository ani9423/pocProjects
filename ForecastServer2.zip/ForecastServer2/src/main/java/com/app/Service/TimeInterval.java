package com.app.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.google.api.gax.core.CredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.MessageReceiver;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.cloud.pubsub.v1.stub.SubscriberStubSettings;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;

@Component
//@EnableAsync
public class TimeInterval {
           
    private String projectId="graphical-elf-409902";
    private String subscriptionId="forecastdataSub";
    ProjectSubscriptionName subscriptionName=null;
    CredentialsProvider credentialsProvider;
    String credentialsFilePath="D:/Downloads/graphical-elf-409902-8d3c72c66aa3.json";
    public TimeInterval() throws IOException {
    	subscriptionName = ProjectSubscriptionName.of(projectId, subscriptionId);
    	SubscriberStubSettings subscriberStubSettings = SubscriberStubSettings.newBuilder().build();
        credentialsProvider = () -> GoogleCredentials.fromStream(new FileInputStream(credentialsFilePath));
    }
	//@Async
	//@Scheduled(fixedRate=5000)
	public void method1()
	{
		Subscriber subscriber= Subscriber.newBuilder(subscriptionName,messageReceiver()).setCredentialsProvider(credentialsProvider).build();
		subscriber.startAsync().awaitRunning();
		System.out.println("Time stamp"+LocalDateTime.now());
	}
	
	public  MessageReceiver  messageReceiver()
	{
		return new MessageReceiver() {

			@Override
			public void receiveMessage(PubsubMessage message, AckReplyConsumer consumer) {
				String a=null;
				if((a=message.getData().toStringUtf8())!=null)
				{
					System.out.println("pubSubMessage Recived>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+a);
					consumer.ack();
				}
				
			}
			
		};
	}
}

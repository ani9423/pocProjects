package com.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.Dao.StoreRepo;
import com.app.pojos.Store;

@Service
@Transactional
public class StoreService implements StoreServiceInterface {

	@Autowired
    private StoreRepo storeDao; 
	
    @Override
	public Store addStore(Store store) {
		
		return storeDao.save(store);
	}

	@Override
	public List<Store> getAllStores() {
		
		return storeDao.findAll();
	}

}

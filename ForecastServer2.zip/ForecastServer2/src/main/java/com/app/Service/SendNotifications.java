package com.app.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.api.gax.core.CredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;

import io.grpc.netty.shaded.io.netty.util.concurrent.Future;

@Service
public class SendNotifications {

	@Value("${gcp.projectId}")
	String ProjectId="graphical-elf-409902";
	
	@Value("${gcp.topicId}")
	String TopicId="forecastnotification";
	
	
	@Value("${gcp.cred}")
	String credentialsFilePath="D:/Downloads/graphical-elf-409902-8d3c72c66aa3.json";
	
	
	public SendNotifications() {
		
	}
    
	
	public Void PublishMesssage(String PublishData) throws InterruptedException, ExecutionException, IOException
	{
//		String ProjectId="graphical-elf-409902";
//		String TopicId="forecastnotification";
//		
		ProjectTopicName topicname=ProjectTopicName.of(ProjectId, TopicId);
		
	
		CredentialsProvider credentialsProvider = () -> GoogleCredentials.fromStream(new FileInputStream(credentialsFilePath));
		
		Publisher publisher= Publisher.newBuilder(topicname).setCredentialsProvider(credentialsProvider).build();
		
		ByteString data = ByteString.copyFromUtf8(PublishData);
		
		PubsubMessage pubsubMessage= PubsubMessage.newBuilder().setData(data).build();
		
		String messageId= publisher.publish(pubsubMessage).get();
		
		
	    System.out.println("!!!!!!!!!!!!!!!Pub sub message id is !!!!!!!!!!!!!!!!!!"+messageId);
		
		publisher.shutdown();
		
		return null;
	}
	
}

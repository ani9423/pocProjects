package com.app.Service;

import java.util.List;

import com.app.pojos.Model;

public interface ModelServiceInterface {
   
	public Model addModel(Model model);
	
	public List<Model> getAllModel();
}

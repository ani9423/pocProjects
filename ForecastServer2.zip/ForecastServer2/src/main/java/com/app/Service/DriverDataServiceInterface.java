package com.app.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.app.pojos.DriverData;

public interface DriverDataServiceInterface {

	public  List<DriverData> getDriverData(Long DriverID);
	
	public DriverData saveData(DriverData driverData);
	
	public double forecastData(String driverId,LocalDate date);
	
	
}

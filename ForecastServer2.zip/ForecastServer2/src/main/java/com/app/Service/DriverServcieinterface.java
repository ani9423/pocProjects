package com.app.Service;

import java.util.List;

import com.app.pojos.Driver;

public interface DriverServcieinterface {

	 public Driver addDriver(Driver driver);
	 public List<Driver> getAll();
}

package com.app.Service;

import java.util.List;

import com.app.pojos.Store;

public interface StoreServiceInterface {
   
	public Store addStore(Store store);
	
	public List<Store> getAllStores();
}

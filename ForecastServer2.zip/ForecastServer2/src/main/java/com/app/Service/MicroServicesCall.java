package com.app.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;


import org.springframework.stereotype.Service;

@Service 
public class MicroServicesCall {

	
	public String callOtherService()
	{
		String re="";
		String location="http://localhost:7070/dept/emp/test";
		
		try {
		URL url= new URL(location);
		
		HttpURLConnection httpConnection= (HttpURLConnection) url.openConnection();
		
		httpConnection.setRequestMethod("GET");
		
    	httpConnection.setRequestProperty("Content-type", "application/json");
//		
//		httpConnection.setDoOutput(true);
//		
//		try(OutputStream os= httpConnection.getOutputStream() ){
//			byte[] input= 
//		}
    	
    	BufferedReader reader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));
    	
    	
    	String result="";
    	
    	while((result=reader.readLine())!=null)
    	{
    		re+=result;
    	}
		
		}
		catch(Exception e )
		{
			System.out.println(e);
		}
		
		
		
		return re;
		
	}
}

package com.app.Service;



public interface ForecastServiceInterface {
   
	
}

package com.app.ForecastModels;

public class  ForecastBaseClass {

	public String trend;
	
	 
}

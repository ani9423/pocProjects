package com.app.ForecastModels;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.app.Service.SendNotifications;
import com.app.pojos.*;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import com.app.pojos.ModelType;

@Service
public class Forecast extends ForecastBaseClass {

//	@Autowired
//	private SendNotifications sendmail;

	private class CalData {
		public double actualdata;
		public double forecastedData;
	}

	public double forecastData(List<DriverData> data, ModelType type) {

		List<CalData> data2 = new ArrayList<>();

		for (DriverData d : data) {
			CalData tem = new CalData();
			tem.actualdata = d.getActualData();
			tem.forecastedData = d.getForecastedData();
			data2.add(tem);
		}
		Gson gson = new Gson();
		String jsonInputString = gson.toJson(data2);
		System.out.println(jsonInputString);

		try {
			CloudFunctions cf = new CloudFunctions();

			HttpURLConnection connection = cf.getConnectionToCloudFunction(type);

			try (OutputStream os = connection.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}

			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line;
			StringBuilder response = new StringBuilder();

			while ((line = reader.readLine()) != null) {
				response.append(line);
			}
			reader.close();
			connection.disconnect();

			System.out.println("Response Body: " + response.toString());

			String ForecastValue = response.toString();

			if (ForecastValue != null) {
				SendNotifications sendmail = new SendNotifications();
				sendmail.PublishMesssage(ForecastValue);
			}

		} catch (Exception e) {
			System.out.println("Failed in GCP Function !!!!!!!!!!!!!! " + e);
		}

		return 0.0;

	}

}

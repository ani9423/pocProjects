package com.app.ForecastModels;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.core.env.Environment;

import com.app.pojos.ModelType;

@Service
public class CloudFunctions {

	@Value("${API.GATEWAY}")
	private String gateway="https://forecast-56yknx1t.uc.gateway.dev";
	
	@Value("${gcp.test}")
	private boolean test;

	URL url;
	
    @Autowired
	public Environment environment;
    
	HttpURLConnection connection;

	public CloudFunctions() {
      System.out.println("cloud function bean created ");
	}

	public HttpURLConnection getConnectionToCloudFunction(ModelType type) throws IOException {
		
		//gateway=environment.getProperty("API.GATEWAY");
		switch (type) {
		// CROSTON,AVG,MOVAVG
		case CROSTON:
			gateway += "/croston";
			break;

		case AVG:
			gateway += "/mvgavg";
			break;

		case MOVAVG:
			gateway += "/mvgavg";
			break;
		}

		url = new URL(gateway);

		HttpURLConnection returnConnection = (HttpURLConnection) url.openConnection();
		returnConnection.setRequestMethod("POST");
		returnConnection.setRequestProperty("Content-Type", "application/json");
		returnConnection.setDoOutput(true);

		return returnConnection;

	}

	public String getGateway() {
		return gateway;
	}

	public void setGateway(String gateway) {
		this.gateway = gateway;
	}

	public boolean isTest() {
		return test;
	}

	public void setTest(boolean test) {
		this.test = test;
	}

	public URL getUrl() {
		return url;
	}

	public void setUrl(URL url) {
		this.url = url;
	}

	public HttpURLConnection getConnection() {
		return connection;
	}

	public void setConnection(HttpURLConnection connection) {
		this.connection = connection;
	}
	
	
	

}

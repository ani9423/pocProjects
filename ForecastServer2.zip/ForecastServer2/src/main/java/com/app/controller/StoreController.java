package com.app.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Service.MicroServicesCall;
import com.app.Service.SendMail;
import com.app.Service.StoreService;
import com.app.pojos.Store;

@RestController
@RequestMapping("/stores")
public class StoreController {

	@Autowired
	private StoreService storeService;
	
	@Autowired
	private SendMail sendmail;
	
	@Autowired
	private MicroServicesCall mc;
	
	Logger logger= LoggerFactory.getLogger(getClass());
	public StoreController() {
		
		
	}
	
	@PostMapping("/add")
	public Store addStore(@RequestBody Store store)
	{
		System.out.println("postmethod");
		return storeService.addStore(store) ;
	}
	
	@GetMapping("/getall")
	public List<Store> getAll()
	{
		
		logger.info("inside Logger bt devloper !!!!!!!!!!!!!!!!!!!!!!!!!!!");
		return storeService.getAllStores();
	}
	
	//For testing will remove in future  
	@GetMapping("/test")
	public String TestingMethod()
	{
		return sendmail.Sendmailmethod();
		//return mc.callOtherService();
	}
}

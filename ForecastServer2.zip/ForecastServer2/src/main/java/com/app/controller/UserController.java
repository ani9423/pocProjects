//package com.app.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import com.app.Dao.UserRepo;
//import com.app.pojos.User;
//import com.app.pojos.UserRole;
//
//@Controller
//public class UserController {
//	
//	@Autowired
//	private UserRepo userRepo;
//
//	@GetMapping("/")
//	public String Loginpage()
//	{
//		return "/index";
//	}
//	
//	@PostMapping("/")
//	public String Loginpost(@RequestParam String email,@RequestParam Long pass, Model map)
//	{
//		
//		try {
//		//User user=userRepo.findbyEmailAndPassward(email, pass).get();
//		
//	   User user= userRepo.FindbymailandPass(email,pass);
//		if(user !=null & user.getRole()== UserRole.CUSTOMER)
//		{
//			map.addAttribute("user", user);
//			return "redirect:/customer/topics";
//		}
//		}
//		catch(Exception e)
//		{
//			System.out.println(e);
//		}
//		return "/userhom";
//		
//	}
//}

package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Service.ModelServcie;
import com.app.pojos.Model;

@RestController
@RequestMapping("/model")
public class ModelController {

	@Autowired 
	private ModelServcie modelService;
	
	@PostMapping("/add")
	public Model addModel(@RequestBody Model model)
	{
		return modelService.addModel(model);
	}
	
	@GetMapping("/getall")
	public List<Model> getAll()
	{
		return modelService.getAllModel();
	}
}

package com.app.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.app.pojos.Driver;

@Repository
public interface DriverDao extends JpaRepository<Driver,Long>  {

	 Driver findByDriverId(String driverId);
	 
	 @Query("select d.id from Driver d where d.driverId=?1")
	 public int getDriverId(String driverId);
}

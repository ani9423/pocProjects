package com.app.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.pojos.Model;
import com.app.pojos.Topic;

@Repository
public interface ModelRepo extends  JpaRepository<Model,Long> {

	
}

package com.app.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Topic;

public interface TopicRepo extends JpaRepository<Topic,Long> {

	
	public List<Topic> findAll();
}

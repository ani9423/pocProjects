package com.app.Dao;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojos.User;
public interface UserRepo extends JpaRepository<User, Long> {

	//Optional<User> findbyEmailAndPassward(String email, Long passward);
	
	@Query("select u from User u where u.email=?1 and u.password=?2")
	User FindbymailandPass(String email, Long pass);
}
